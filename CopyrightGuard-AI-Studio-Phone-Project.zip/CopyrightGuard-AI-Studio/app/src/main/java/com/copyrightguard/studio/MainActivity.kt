package com.copyrightguard.studio

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(8, 10, 18)
    private val panel = Color.rgb(20, 24, 38)
    private val accent = Color.rgb(133, 92, 255)
    private val white = Color.rgb(245, 246, 255)
    private val muted = Color.rgb(164, 170, 190)

    private lateinit var status: TextView
    private lateinit var selectedVideo: TextView
    private lateinit var narrationInput: EditText
    private var videoUri: Uri? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        page.addView(label("COPYRIGHTGUARD", 12, accent, true))
        page.addView(label("AI Studio", 32, white, true))
        page.addView(label("Your rights-first video workspace", 14, muted, false))
        page.addView(space(22))

        val hero = card()
        hero.addView(label("VIDEO WORKSPACE", 11, accent, true))
        hero.addView(label("Create videos with rights you can prove.", 21, white, true))
        hero.addView(label("Import your own footage or material you are licensed to use. This app does not remove copyright ownership or bypass Content ID.", 13, muted, false))
        val import = button("＋  Import video")
        import.setOnClickListener { openVideoPicker() }
        hero.addView(import)
        selectedVideo = label("No video selected", 13, muted, false)
        hero.addView(selectedVideo)
        page.addView(hero)
        page.addView(space(14))

        page.addView(featureCard("01  COPYRIGHT RISK REVIEW",
            "A guided rights checklist for footage, music, images, stock assets and permissions.",
            "Open rights checklist") {
            showRightsChecklist()
        })
        page.addView(featureCard("02  AI VOICEOVER",
            "Draft original narration and preview it with your device's installed text-to-speech voice.",
            "Open voiceover studio") {
            showVoiceover()
        })
        page.addView(featureCard("03  AUDIO WORKFLOW",
            "Plan replacement audio using original or properly licensed tracks. No Content ID evasion tools.",
            "Audio guidance") {
            showMessage("Audio workflow", "Use audio you created, commissioned, or licensed for your intended YouTube use. Keep the license and attribution details with your project.")
        })
        page.addView(featureCard("04  16:9 VIDEO EDITOR",
            "Prepare a landscape export plan, subtitles and editing notes. Full timeline rendering is a later development phase.",
            "Editor settings") {
            showEditorSettings()
        })
        page.addView(featureCard("05  YOUTUBE READINESS",
            "Check permissions, reused-content risk, attribution and monetization documentation before publishing.",
            "Run readiness checklist") {
            showReadiness()
        })
        page.addView(featureCard("06  LICENSE MANAGER",
            "Keep a simple record of asset owners, license links, dates and permitted uses.",
            "License record guide") {
            showMessage("License manager", "For every third-party asset, record its title, creator, source URL, license type, date obtained, permitted platforms, commercial-use permission and attribution requirements.")
        })

        page.addView(space(18))
        status = label("Ready • Import a video to begin", 13, muted, false)
        page.addView(status)
        page.addView(space(12))
        page.addView(label("DISCLAIMER", 11, accent, true))
        page.addView(label("A risk review is not legal advice and cannot predict every YouTube Content ID claim or monetization decision. Only use content you own or are authorized to use.", 12, muted, false))

        scroll.addView(page)
        setContentView(scroll)
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, 1001)
    }

    @Deprecated("Legacy callback retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            videoUri = uri
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(this, uri)
                val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    ?: "Selected video"
                val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()?.let { "${it / 60000}m ${(it / 1000) % 60}s" } ?: "Duration unavailable"
                val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH) ?: "?"
                val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT) ?: "?"
                selectedVideo.text = "$title\n${width}×${height} • $duration"
                status.text = "Video imported • Review usage rights before editing"
            } catch (e: Exception) {
                selectedVideo.text = "Video selected: ${uri.lastPathSegment ?: "media file"}"
                status.text = "Imported. Metadata could not be read for this file."
            } finally {
                retriever.release()
            }
        }
    }

    private fun showRightsChecklist() {
        showMessage("Copyright risk review",
            "Before publishing, verify:\n\n1. Do you own the footage, or have written permission?\n2. Is the music licensed for YouTube and commercial use if needed?\n3. Are images, clips, fonts and sound effects cleared?\n4. Does the license allow editing and monetization?\n5. Have you kept receipts, license URLs and permission emails?\n\nThis checklist does not scan YouTube's private Content ID database.")
    }

    private fun showVoiceover() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            setBackgroundColor(panel)
        }
        layout.addView(label("VOICEOVER STUDIO", 12, accent, true))
        layout.addView(label("Write original narration", 21, white, true))
        narrationInput = EditText(this).apply {
            hint = "अपनी हिंदी कहानी या narration यहाँ लिखें…"
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            minLines = 5
            gravity = Gravity.TOP
            setBackgroundColor(Color.rgb(31, 36, 54))
        }
        layout.addView(narrationInput)
        val speak = button("▶  Preview voice")
        speak.setOnClickListener {
            val text = narrationInput.text.toString().trim()
            if (text.isEmpty()) {
                status.text = "Enter narration first."
            } else if (ttsReady) {
                tts?.language = Locale("hi", "IN")
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cg_preview")
                status.text = "Playing device voice preview"
            } else {
                status.text = "Text-to-speech is still initializing. Try again."
            }
        }
        layout.addView(speak)
        showCustomDialog("Voiceover Studio", layout)
    }

    private fun showEditorSettings() {
        showMessage("16:9 editor settings",
            "Recommended landscape project:\n\nCanvas: 1920 × 1080\nAspect ratio: 16:9\nFrame rate: match the original footage (usually 30 fps)\nAudio: original or properly licensed\nExport: H.264 MP4 where supported\n\nThis starter build records the workflow settings; timeline editing and rendered export are not implemented yet.")
    }

    private fun showReadiness() {
        showMessage("YouTube readiness",
            "Publishing checklist:\n\n□ You own or have permission for every asset.\n□ Licenses permit YouTube publication and monetization.\n□ Third-party clips are not merely resized, cropped or mirrored.\n□ Your video adds substantial original value where third-party material is lawfully used.\n□ Music and image attribution is included where required.\n□ You have saved permission and license evidence.\n\nA completed checklist cannot guarantee YPP approval.")
    }

    private fun showMessage(title: String, message: String) {
        val view = label(message, 14, white, false).apply { setPadding(dp(20), dp(12), dp(20), dp(12)) }
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun showCustomDialog(title: String, view: View) {
        android.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(view)
            .setNegativeButton("Close", null)
            .show()
    }

    private fun featureCard(title: String, description: String, action: String, onClick: () -> Unit): LinearLayout {
        val box = card()
        box.addView(label(title, 12, accent, true))
        box.addView(label(description, 14, white, false))
        box.addView(button(action).apply { setOnClickListener { onClick() } })
        return box
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        setBackgroundColor(panel)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        )
        params.bottomMargin = dp(12)
        layoutParams = params
    }

    private fun button(text: String) = Button(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent))
        isAllCaps = false
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(4), 0, dp(7))
    }

    private fun space(height: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) {
            tts?.language = Locale("hi", "IN")
            if (::status.isInitialized) status.text = "Ready • Hindi voice preview available"
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
