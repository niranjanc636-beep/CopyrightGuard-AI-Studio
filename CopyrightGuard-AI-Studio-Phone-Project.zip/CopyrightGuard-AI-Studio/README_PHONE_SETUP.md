# CopyrightGuard AI Studio — phone-only build

## What this starter APK currently does
- Premium dark Android dashboard
- Imports a video through Android's document picker
- Reads basic video metadata locally
- Shows rights-review and YouTube-readiness checklists
- Previews original Hindi narration using Android TextToSpeech

## Not implemented in this starter
This is the first buildable foundation, not the complete AI product. It does not remove copyright, evade Content ID, query YouTube's private Content ID database, perform AI audio fingerprint matching, generate cloud AI voices, edit a multitrack timeline, or render a finished edited video. Those require later modules and, for cloud AI, a separately configured backend/API key.

## Phone-only GitHub setup
1. Create a GitHub repository named `CopyrightGuard-AI-Studio`.
2. Download this ZIP to your Android phone.
3. In Chrome, open your repository and tap **Add file > Upload files**.
4. Upload the ZIP itself: `CopyrightGuard-AI-Studio-Phone-Project.zip`. Do not extract it first.
5. Commit the ZIP to the `main` branch.
6. Create the workflow file in GitHub: **Add file > Create new file**.
7. For the filename, enter `.github/workflows/android.yml`.
8. Paste the workflow contents from the `android.yml` file included in this ZIP. To view it, open the ZIP using your phone's Files app and navigate to `.github/workflows/android.yml`.
9. Commit the new workflow file to `main`.
10. Open the repository's **Actions** tab. Select **Build CopyrightGuard APK** and tap **Run workflow** if it has not started automatically.
11. Wait for the green successful run. Open the run and download the `CopyrightGuard-AI-Studio-debug` artifact.
12. Extract the downloaded artifact ZIP and tap `app-debug.apk`.
13. If Android asks, allow Chrome or Files to install unknown apps, then install.

## Build requirements
- JDK 17
- Gradle 8.13
- Android Gradle Plugin 8.13.2
- Android SDK 35
- Minimum Android API 26

## Troubleshooting
- If the workflow fails, open the failed run and copy the first red error section.
- Confirm the repository root contains `CopyrightGuard-AI-Studio-Phone-Project.zip` and `.github/workflows/android.yml`.
- Do not upload the project ZIP into a subfolder.
